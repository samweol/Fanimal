package com.project.care.dto;

import lombok.Data;

@Data
public class DosageDTO {
	private String dseq; 
	private String usage; 
	private String amount;
	private String pdate;
}