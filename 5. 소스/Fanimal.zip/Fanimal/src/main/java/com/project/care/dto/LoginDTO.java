package com.project.care.dto;

import lombok.Data;

@Data
public class LoginDTO {

	private String id;
	private String password;
}
