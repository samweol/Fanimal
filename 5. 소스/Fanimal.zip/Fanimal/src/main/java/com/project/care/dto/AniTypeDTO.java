package com.project.care.dto;

import lombok.Data;

@Data
public class AniTypeDTO {
	
	private int tseq;
	private String type;
	
}
