package com.project.care.dto;

import lombok.Data;

@Data
public class companyviewDTO {
	private String seq;
	private String hosname;
	private String license;
	private String starttime;
	private String endtime;
	private String open;
	private String info;
	private String state;
	
}
