package com.project.care.dto;

import lombok.Data;

@Data
public class UserAniDTO {

	private int uaseq;
	private int useq;
	private int aseq;
	
	
}
