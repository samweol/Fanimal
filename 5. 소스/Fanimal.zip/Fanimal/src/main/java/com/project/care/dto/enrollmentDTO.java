package com.project.care.dto;

import lombok.Data;

@Data
public class enrollmentDTO {
	private String Id;
	private String hosname;
	private int license;
	private String info;
	private String starttime;
	private String endtime;
	private String open;
	
}
