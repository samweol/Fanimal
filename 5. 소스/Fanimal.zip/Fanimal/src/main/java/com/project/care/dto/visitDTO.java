package com.project.care.dto;

public class visitDTO {
	private String visitseq;
	private String visit;
}
