package com.project.care.dto;

import lombok.Data;

@Data
public class PidDTO {
	private String pidseq;
	private String proingseq;
	private String dseq;
	private String pseq;
}
