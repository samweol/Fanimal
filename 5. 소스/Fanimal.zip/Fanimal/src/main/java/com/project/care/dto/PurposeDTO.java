package com.project.care.dto;

import lombok.Data;

@Data
public class PurposeDTO {

	private String pseq;
	private String purpose;
}
