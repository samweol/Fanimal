package com.project.care.dto;

import lombok.Data;

@Data
public class productDTO {
	private String pseq;
	private String pname;
}
