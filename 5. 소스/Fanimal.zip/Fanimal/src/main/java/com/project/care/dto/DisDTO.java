package com.project.care.dto;

import lombok.Data;

@Data
public class DisDTO {
	private int dseq;
	private String dname;
}
