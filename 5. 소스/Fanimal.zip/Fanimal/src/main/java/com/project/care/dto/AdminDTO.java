package com.project.care.dto;

import lombok.Data;

@Data
public class AdminDTO {

	private String id;
	private String password;
}
