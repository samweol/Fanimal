package com.project.care.dto;

import lombok.Data;

@Data
public class FreeCommentDTO {
	
	private String caseq;
	private String content;
	private String answerDay;
	private String id;
	private String comuseq;
	
}
