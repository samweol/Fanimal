package com.project.care.dto;

import lombok.Data;

@Data
public class AniDisDTO {
	private int adseq;
	private int aseq;
	private String dseq;
}
