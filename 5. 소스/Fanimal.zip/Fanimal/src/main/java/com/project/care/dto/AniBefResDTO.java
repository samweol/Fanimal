package com.project.care.dto;

public class AniBefResDTO {

}
