package com.project.care.dto;

import lombok.Data;

@Data
public class reservationDTO {
	
	private String seq;
	private String name;
	private String visit;
	private String resdate;
	private String purpose;
	
	private String username;
	private String tel;
	private String uniqueness;
	
	private String pic;
}
