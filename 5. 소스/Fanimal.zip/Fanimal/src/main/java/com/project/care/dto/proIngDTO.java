package com.project.care.dto;

import lombok.Data;

@Data
public class proIngDTO {
	private String proingseq;
	private String iseq;
	private String pseq;
}
