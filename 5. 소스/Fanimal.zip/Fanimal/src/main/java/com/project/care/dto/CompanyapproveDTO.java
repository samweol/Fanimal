package com.project.care.dto;

import lombok.Data;

@Data
public class CompanyapproveDTO {
	private String cseq;
	private String id;
	private String name;
	private String tel;
	private String address;
	private String business;
	
	private String hosname;
	private String license;
	private String info;
	private String starttime;
	private String endtime;
	
	private String stat;
}
