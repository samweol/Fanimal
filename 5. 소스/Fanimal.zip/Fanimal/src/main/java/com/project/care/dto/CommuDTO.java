package com.project.care.dto;

import lombok.Data;

@Data
public class CommuDTO {
	
	private String commuseq;
	private String title;
	private String id;
	private String postDay;
	private String readcount;
	private String attachFile;
	private String typeseq;
	private String field;
	
	private String orgattachFile;
	private String nickname;
	
	
	

}
