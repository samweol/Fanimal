package com.project.care.dto;

import lombok.Data;

@Data
public class componentDTO {
	private String iseq;
	private String component;
}
