package com.project.care.dto;

import lombok.Data;

@Data
public class AniKindDTO {
	private int kseq;
	private int tseq;
	private String kind;
	
}
