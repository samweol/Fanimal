package com.project.care.dto;

/**
 * 병원 문의 게시판
 * @author 고민지
 *
 */
public class HospitalInqurieDTO {
	

}
