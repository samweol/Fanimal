package com.project.care.dto;

import lombok.Data;

@Data
public class EditAniViewDTO {

	private String name;
	private String gender;
	private String age;
	private String birth;
	private String neutral;
	private String weight;
	private String dis;
	private String state;
	private String pic;
	
	
	
	
	
}
