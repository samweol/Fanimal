package com.project.care.main.admin.usersearch;

public class UserInfoView {

}
